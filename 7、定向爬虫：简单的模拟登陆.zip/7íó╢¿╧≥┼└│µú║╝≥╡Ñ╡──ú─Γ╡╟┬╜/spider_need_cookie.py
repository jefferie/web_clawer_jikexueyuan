#-*-coding:utf8-*-

import requests
from lxml import etree

cook = {"Cookie": ""}

url = 'https://weibo.cn/hoopchina'
html = requests.get(url, cookies = cook).content
# html = bytes(bytearray(html, encoding = 'utf-8'))

# print(html)
selector = etree.HTML(html)
content = selector.xpath('//span[@class="ctt"]')
for each in content:
    text = each.xpath('string(.)')
    # b=1
    print(text)
