#-*-coding:utf8-*-

import smtplib
import requests
from lxml import etree
from email.mime.text import MIMEText
import importlib
import sys
importlib.reload(sys)
import os
import time

class mail_helper(object):
    def __init__(self):
        self.mail_host = "smtp.sina.com"
        self.mail_user = "jefferiewu"
        self.mail_pass = ""
        self.mail_postfix = "sina.com"

    def send_mail(self, to_list, sub, content):
        me = "xxoohelper"+"<"+self.mail_user+"@"+self.mail_postfix+">"
        msg = MIMEText(content, _subtype='plain', _charset='utf-8')
        msg['Subject'] = sub
        msg['From'] = me
        msg['To'] = ";".join(to_list)
        try:
            server = smtplib.SMTP()
            server.connect(self.mail_host)
            server.login(self.mail_user, self.mail_pass)
            server.sendmail(me, to_list, msg.as_string())
            server.close()
            return True
        except Exception as e:
            print(str(e))
            return False

class xxoohelper(object):

    # 这个类实现将爬取微博第一条内容

    def __init__(self):
        self.url = 'https://weibo.cn/ithome'

    def getContent(self):
        cook = {"Cookie": "SCF=As0C1kawsntIbvAo1AlUpVcR8ITHKVqT1H2sUhAGUvshakbZwJsHb3UJoJmXZ7pTfQrkiDxKdPCdi1jTIlVQcqc.; SUHB=0laVp76SwBkETv; _T_WM=7ae4d86948c9d1e18f6468d1a3b2eed2; SUB=_2A2538sO8DeRhGeNJ71UU-CrIzzqIHXVVHO30rDV6PUJbkdAKLUjRkW1NS9lT-RWtXuy-i_PlvO1RCMazBKTa6fl7"}
        html = requests.get(self.url, cookies = cook).content
        selector = etree.HTML(html)
        content = selector.xpath('//span[@class="ctt"]')
        newcontent = content[3].xpath('string(.)').replace('http://','')
        sendtime = selector.xpath('//span[@class="ct"]/text()')
        sendtime = sendtime[0]
        sendtext = newcontent+sendtime
        return sendtext

    def tosave(self, text):
        f = open('weibo.txt', 'a', encoding='UTF-8')
        f.write(text + '\n')
        f.close()

    def tocheck(self, data):
        if not os.path.exists('weibo.txt'):
            return True
        else:
            f = open('weibo.txt', 'r', encoding='UTF-8')
            existweibo = f.readlines()
            if data + '\n' in existweibo:
                return False
            else:
                return True


if __name__ == '__main__':
    mailto_list = ['1269065253@qq.com']
    helper = xxoohelper()
    while True:
        content = helper.getContent()
        if helper.tocheck(content):
            if mail_helper().send_mail(mailto_list, u"IT之家更新啦！", content):
                print('发送成功')
            else:
                print('发送失败')
            helper.tosave(content)
            print(content)
        else:
            print(u'pass')
        time.sleep(30)

