import requests
import re
# url = "https://www.crowdfunder.com/browse/deals"
url = 'https://www.crowdfunder.com/?q=filter&page=2'

# html = requests.get(url)
#  print(html.text)
#
# title = re.findall(r'"card-title">(.*?)</div>',html.text, re.S)
# for each in title:
#     print(each)

data = {
    'entitle_only':'true',
    'page':'2'
}
html_post = requests.post(url, data = data)
title = re.findall(r'"card-title">(.*?)</div>',html_post.text, re.S)
for each in title:
    print(each)
