#-*-coding:utf8-*-

import requests
html = requests.get('http://tieba.baidu.com/p/3522395718?')
newpage = 'http://tieba.baidu.com/p/3522395718?pn=' + str(1)
print(html.text)
print(newpage)