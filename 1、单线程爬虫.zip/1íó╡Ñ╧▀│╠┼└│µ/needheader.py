#-*—coding:utf8-*-

import importlib
import requests
import re

#下面两行是编码转换的功能
import sys
importlib.reload(sys)

#hea是我们自己构造的一个字典，里面保存了user-agent

# html = requeshea = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36'}ts.get('http://jp.tingroom.com/yuedu/yd300p/')
html = requests.get('http://jp.tingroom.com/yuedu/yd300p/', headers = hea)
html.encoding = 'utf-8' #这一行是将编码转为utf-8,否则中文会显示乱码。

#显示中文
# title = re.findall(r'color: #039;">(.*?)</a>',html.text,re.S)
# for each in title:
#     print(each)

#显示日文
Japanese = re.findall(r'"color:#666666;">(.*?)</span>',html.text,re.S)
for each in Japanese:
    print(each)

# print(html.text)
