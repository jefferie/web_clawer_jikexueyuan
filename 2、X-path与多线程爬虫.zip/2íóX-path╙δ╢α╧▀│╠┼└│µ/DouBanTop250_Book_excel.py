# -*- coding: utf-8 -*-

from lxml import html
import requests
import importlib
import sys
importlib.reload(sys)
import openpyxl

def save_to_excel(name,fenshu,renshu, xinxi, mingyan, lianjie):

    wb = openpyxl.Workbook()
    ws = wb.active

    #定义列表签
    ws['A1'] = "排名"
    ws['B1'] = "书名"
    ws['C1'] = "评分"
    ws['D1'] = "评分人数"
    # ws['E1'] = "类型"
    ws['E1'] = "名言"
    # ws['G1'] = "制片国家"
    ws['F1'] = "信息"
    ws['G1'] = "链接"

    #录入电影信息
    for i in range(len(name)):
        result = [i+1,name[i],fenshu[i],renshu[i], mingyan[i], xinxi[i], lianjie[i]]
        ws.append(result)
    wb.save("豆瓣图书TOP250.xlsx")


def spider():

    page = []
    name = []
    fenshu = []
    renshu = []
    # leixing = []
    # riqi = []
    # guojia = []
    xinxi = []
    mingyan = []
    lianjie = []

    #先实现翻页功能
    for i in range(10):
        url = 'https://book.douban.com/top250?start={}'.format(i*25)
        page.append(url)

        con = requests.get(url).content
        sel = html.fromstring(con)

        # 所有的信息都在class属性为info的div标签里，可以先把这个节点取出来
        for each in sel.xpath('//tr[@class="item"]/td[2]'):
            # 影片名称
            title = each.xpath('div[@class="pl2"]/a/@title')[0]

            info = each.xpath('p[@class="pl"]/text()')
            # 评分
            rate = each.xpath('div[@class="star clearfix"]/span[@class="rating_nums"]/text()')[0]
            # 评分人数
            comCount = each.xpath('div[@class="star clearfix"]/span[@class="pl"]/text()')[0].replace("\n", "").replace("                    ", "").replace("人评价", "").replace("                ","").replace("(","").replace(")","")

            # 导演&演员信息
            info_1 = info[0]
            #简介
            quote = each.xpath('p[2]/span["class=inq"]/text()')
            if quote:
                quote = quote[0]
            else:
                quote = ''
            #链接
            link = each.xpath('div[@class="pl2"]/a/@href')[0]

            name.append(title)
            fenshu.append(rate)
            renshu.append(comCount)
            # leixing.append(geners)
            # riqi.append(date)
            # guojia.append(country)
            xinxi.append(info_1)
            mingyan.append(quote)
            lianjie.append(link)
    save_to_excel(name,fenshu,renshu, xinxi, mingyan, lianjie)

if __name__ == '__main__':
    spider()


