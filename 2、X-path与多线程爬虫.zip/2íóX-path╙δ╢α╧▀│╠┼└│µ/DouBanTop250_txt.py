# -*- coding: utf-8 -*-

from lxml import html
import requests
import importlib
import sys
importlib.reload(sys)

k = 1
for i in range(10):
    url = 'https://movie.douban.com/top250?start={}&filter='.format(i*25)
    con = requests.get(url).content
    sel = html.fromstring(con)

    # 所有的信息都在class属性为info的div标签里，可以先把这个节点取出来
    for each in sel.xpath('//div[@class="info"]'):
        # 影片名称
        title = each.xpath('div[@class="hd"]/a/span[@class="title"]/text()')
        fulltitle = ''
        for j in title:
            fulltitle += j
        info = each.xpath('div[@class="bd"]/p[1]/text()')
        # 导演演员信息
        info_1 = info[0].replace(" ", "").replace("\n", "").replace(":","：")
        # 上映日期
        date = info[1].replace(" ", "").replace("\n", "").split("/")[0]
        # 制片国家
        country = info[1].replace(" ", "").replace("\n", "").split("/")[1]
        # 影片类型
        geners = info[1].replace(" ", "").replace("\n", "").split("/")[2]
        # 评分
        rate = each.xpath('div[@class="bd"]//div[@class="star"]/span[@class="rating_num"]/text()')[0]
        # 评论人数
        comCount = each.xpath('div[@class="bd"]/div[@class="star"]/span[4]/text()')[0]
        #简介
        quote = each.xpath('div[@class="bd"]/p[@class="quote"]/span["class=inq"]/text()')
        link = each.xpath('div[@class="hd"]/a/@href')[0]
        if quote:
            quote = quote[0]
        else:
            quote = ''

        # 打印结果看看
        print("TOP%s" % str(k))
        print(fulltitle, info_1, rate, date, country, geners, comCount, quote, link)

        # 写入文件
        f = open("DouBanTop250.txt", "a+",encoding='utf-8')
        f.writelines("TOP%s\n影片名称：%s\n评分：%s\n评分人数：%s\n上映日期：%s\n上映国家：%s\n%s\n简介：%s\n链接：%s\n" % (k, fulltitle, rate, comCount, date, country, info_1, quote))
        f.writelines("==========================\n")
        f.close()
        k += 1
