# -*- coding: utf-8 -*-

from lxml import html
import requests
import importlib
import sys
importlib.reload(sys)
import openpyxl

def save_to_excel(name,fenshu,renshu,leixing,riqi, guojia, xinxi, mingyan, lianjie):

    wb = openpyxl.Workbook()
    ws =wb.active

    #定义列表签
    ws['A1'] = "排名"
    ws['B1'] = "电影名称"
    ws['C1'] = "评分"
    ws['D1'] = "评分人数"
    ws['E1'] = "类型"
    ws['F1'] = "上映日期"
    ws['G1'] = "制片国家"
    ws['H1'] = "导演&演员表"
    ws['I1'] = "名言"
    ws['J1'] = "链接"

    #录入电影信息
    for i in range(len(name)):
        result = [i+1,name[i],fenshu[i],renshu[i],leixing[i],riqi[i], guojia[i], xinxi[i], mingyan[i], lianjie[i]]
        ws.append(result)
    wb.save("豆瓣电影TOP250.xlsx")


def spider():

    page = []
    name = []
    fenshu = []
    renshu = []
    leixing = []
    riqi = []
    guojia = []
    xinxi = []
    mingyan = []
    lianjie = []

    #先实现翻页功能
    for i in range(10):
        url = 'https://movie.douban.com/top250?start={}&filter='.format(i*25)
        page.append(url)

        con = requests.get(url).content
        sel = html.fromstring(con)

        # 所有的信息都在class属性为info的div标签里，可以先把这个节点取出来
        for each in sel.xpath('//div[@class="info"]'):
            # 影片名称
            title = each.xpath('div[@class="hd"]/a/span[@class="title"]/text()')
            fulltitle = ''
            for j in title:
                fulltitle += j
            info = each.xpath('div[@class="bd"]/p[1]/text()')
            # 评分
            rate = each.xpath('div[@class="bd"]//div[@class="star"]/span[@class="rating_num"]/text()')[0]
            # 评分人数
            comCount = each.xpath('div[@class="bd"]/div[@class="star"]/span[4]/text()')[0]
            # 影片类型
            geners = info[1].replace(" ", "").replace("\n", "").split("/")[2]
            # 上映日期
            date = info[1].replace(" ", "").replace("\n", "").split("/")[0]
            # 制片国家
            country = info[1].replace(" ", "").replace("\n", "").split("/")[1]
            # 导演&演员信息
            info_1 = info[0].replace(" ", "").replace("\n", "").replace(":","：")
            #简介
            quote = each.xpath('div[@class="bd"]/p[@class="quote"]/span["class=inq"]/text()')
            if quote:
                quote = quote[0]
            else:
                quote = ''
            #链接
            link = each.xpath('div[@class="hd"]/a/@href')[0]

            name.append(fulltitle)
            fenshu.append(rate)
            renshu.append(comCount)
            leixing.append(geners)
            riqi.append(date)
            guojia.append(country)
            xinxi.append(info_1)
            mingyan.append(quote)
            lianjie.append(link)
    save_to_excel(name,fenshu,renshu,leixing,riqi, guojia, xinxi, mingyan, lianjie)

if __name__ == '__main__':
    spider()


